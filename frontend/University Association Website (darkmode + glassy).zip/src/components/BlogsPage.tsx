import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Search, Filter, Calendar, User, ArrowLeft } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { LikeButton } from './LikeButton';
import { CommentSection } from './CommentSection';

interface BlogsPageProps {
  onNavigate: (page: string, id?: string) => void;
  selectedId?: string;
}

const allBlogs = [
  {
    id: '1',
    title: 'The Future of Artificial Intelligence in Computer Engineering',
    excerpt: 'Exploring how AI is revolutionizing the field of computer engineering and its implications for students and professionals.',
    content: 'Artificial Intelligence is transforming every aspect of computer engineering...',
    author: 'Dr. Ahmad Mohammadi',
    date: '2024-01-15',
    category: 'Technology',
    readTime: '8 min read',
    tags: ['AI', 'Machine Learning', 'Future Tech'],
    thumbnail: 'https://images.unsplash.com/photo-1738003667850-a2fb736e31b3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpZmljaWFsJTIwaW50ZWxsaWdlbmNlJTIwcmVzZWFyY2h8ZW58MXx8fHwxNzU3MzQzNjk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    likes: 42,
    isLiked: false
  },
  {
    id: '2',
    title: 'Best Practices for Software Development in Academic Projects',
    excerpt: 'A comprehensive guide to implementing industry-standard practices in university software projects.',
    content: 'Software development in academic settings requires a unique approach...',
    author: 'Prof. Sara Hashemi',
    date: '2024-01-10',
    category: 'Development',
    readTime: '12 min read',
    tags: ['Software Development', 'Best Practices', 'Academic'],
    thumbnail: 'https://images.unsplash.com/photo-1725080503775-a418e90cab6c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2Z0d2FyZSUyMGRldmVsb3BtZW50JTIwY29tcHV0ZXJ8ZW58MXx8fHwxNzU3NDM3MDYyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    likes: 28,
    isLiked: true
  },
  {
    id: '3',
    title: 'Career Opportunities in Computer Engineering',
    excerpt: 'Understanding the diverse career paths available for computer engineering graduates.',
    content: 'Computer engineering offers a wide range of career opportunities...',
    author: 'Dr. Reza Gholami',
    date: '2024-01-08',
    category: 'Career',
    readTime: '6 min read',
    tags: ['Career', 'Job Market', 'Professional Development'],
    thumbnail: 'https://images.unsplash.com/photo-1752118464988-2914fb27d0f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJlZXIlMjBkZXZlbG9wbWVudCUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NTc0MzcwNjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    likes: 35,
    isLiked: false
  },
  {
    id: '4',
    title: 'Introduction to Quantum Computing',
    excerpt: 'A beginner-friendly introduction to the principles and applications of quantum computing.',
    content: 'Quantum computing represents a paradigm shift in computational capabilities...',
    author: 'Dr. Maryam Alavi',
    date: '2024-01-05',
    category: 'Technology',
    readTime: '15 min read',
    tags: ['Quantum Computing', 'Physics', 'Advanced Tech'],
    thumbnail: 'https://images.unsplash.com/photo-1752451399417-eb6e072269bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxxdWFudHVtJTIwY29tcHV0aW5nJTIwdGVjaG5vbG9neXxlbnwxfHx8fDE3NTc0MjY0ODZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    likes: 67,
    isLiked: false
  },
  {
    id: '5',
    title: 'Building Secure Web Applications',
    excerpt: 'Security considerations and best practices for modern web application development.',
    content: 'Security should be a primary concern in web application development...',
    author: 'Prof. Hassan Karimi',
    date: '2024-01-03',
    category: 'Security',
    readTime: '10 min read',
    tags: ['Web Security', 'Cybersecurity', 'Web Development'],
    thumbnail: 'https://images.unsplash.com/photo-1639503547276-90230c4a4198?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjeWJlcnNlY3VyaXR5JTIwd2ViJTIwc2VjdXJpdHl8ZW58MXx8fHwxNzU3NDM3MTg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    likes: 53,
    isLiked: true
  },
  {
    id: '6',
    title: 'Data Structures and Algorithms: A Practical Guide',
    excerpt: 'Essential data structures and algorithms every computer engineering student should master.',
    content: 'Understanding data structures and algorithms is fundamental to computer engineering...',
    author: 'Dr. Ali Rezaei',
    date: '2024-01-01',
    category: 'Education',
    readTime: '14 min read',
    tags: ['Data Structures', 'Algorithms', 'Computer Science'],
    thumbnail: 'https://images.unsplash.com/photo-1664854953181-b12e6dda8b7c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXRhJTIwc3RydWN0dXJlcyUyMGFsZ29yaXRobXMlMjBwcm9ncmFtbWluZ3xlbnwxfHx8fDE3NTc0MzcxODd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    likes: 89,
    isLiked: false
  }
];

export function BlogsPage({ onNavigate, selectedId }: BlogsPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedBlog, setSelectedBlog] = useState<string | null>(selectedId || null);

  const categories = ['all', 'Technology', 'Development', 'Career', 'Security', 'Education'];

  const filteredBlogs = allBlogs.filter(blog => {
    const matchesSearch = blog.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         blog.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         blog.author.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || blog.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const currentBlog = selectedBlog ? allBlogs.find(blog => blog.id === selectedBlog) : null;

  if (currentBlog) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Button 
          variant="ghost" 
          onClick={() => setSelectedBlog(null)}
          className="mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Blogs
        </Button>
        
        <article className="space-y-8">
          <div className="mb-8">
            <Badge className="mb-4">{currentBlog.category}</Badge>
            <h1 className="text-4xl mb-4">{currentBlog.title}</h1>
            <div className="w-full h-64 md:h-80 mb-6 rounded-lg overflow-hidden">
              <ImageWithFallback
                src={currentBlog.thumbnail}
                alt={currentBlog.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex items-center gap-4 text-muted-foreground mb-6">
              <div className="flex items-center">
                <User className="mr-2 h-4 w-4" />
                {currentBlog.author}
              </div>
              <div className="flex items-center">
                <Calendar className="mr-2 h-4 w-4" />
                {currentBlog.date}
              </div>
              <span>{currentBlog.readTime}</span>
            </div>
            <div className="flex flex-wrap gap-2 mb-6">
              {currentBlog.tags.map((tag) => (
                <Badge key={tag} variant="outline">
                  {tag}
                </Badge>
              ))}
            </div>
            
            {/* Like Button */}
            <div className="flex items-center space-x-4 mb-8 pb-6 border-b border-border">
              <LikeButton 
                postId={currentBlog.id}
                initialLikes={currentBlog.likes}
                initialIsLiked={currentBlog.isLiked}
                showCount={true}
              />
            </div>
          </div>
          
          <div className="prose prose-lg max-w-none">
            <p className="text-xl text-muted-foreground mb-6">
              {currentBlog.excerpt}
            </p>
            <div className="space-y-4">
              <p>
                This is a detailed blog post about {currentBlog.title.toLowerCase()}. 
                The content would include comprehensive information, examples, and insights 
                related to the topic.
              </p>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod 
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim 
                veniam, quis nostrud exercitation ullamco laboris.
              </p>
              <p>
                Duis aute irure dolor in reprehenderit in voluptate velit esse cillum 
                dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non 
                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
              </p>
            </div>
          </div>
          
          {/* Comments Section */}
          <div className="mt-12">
            <CommentSection postId={currentBlog.id} postType="blog" />
          </div>
        </article>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-4xl mb-4">Blog Posts</h1>
        <p className="text-xl text-muted-foreground">
          Insights, tutorials, and updates from our computer engineering community
        </p>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search blogs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-full sm:w-48">
            <Filter className="mr-2 h-4 w-4" />
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((category) => (
              <SelectItem key={category} value={category}>
                {category === 'all' ? 'All Categories' : category}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Blog Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredBlogs.map((blog) => (
          <Card key={blog.id} className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden">
            <div className="h-48 relative">
              <ImageWithFallback
                src={blog.thumbnail}
                alt={blog.title}
                className="w-full h-full object-cover"
              />
            </div>
            <CardHeader>
              <div className="flex items-center justify-between mb-2">
                <Badge variant="secondary">{blog.category}</Badge>
                <span className="text-sm text-muted-foreground">{blog.readTime}</span>
              </div>
              <CardTitle className="line-clamp-2">{blog.title}</CardTitle>
              <CardDescription className="line-clamp-3">{blog.excerpt}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <User className="mr-1 h-3 w-3" />
                    {blog.author}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="mr-1 h-3 w-3" />
                    {blog.date}
                  </div>
                </div>
                <div className="flex flex-wrap gap-1">
                  {blog.tags.slice(0, 2).map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {blog.tags.length > 2 && (
                    <Badge variant="outline" className="text-xs">
                      +{blog.tags.length - 2}
                    </Badge>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <LikeButton 
                    postId={blog.id}
                    initialLikes={blog.likes}
                    initialIsLiked={blog.isLiked}
                    showCount={true}
                  />
                  <Button 
                    size="sm"
                    onClick={() => setSelectedBlog(blog.id)}
                  >
                    Read More
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredBlogs.length === 0 && (
        <div className="text-center py-12">
          <p className="text-xl text-muted-foreground">
            No blogs found matching your search criteria.
          </p>
        </div>
      )}
    </div>
  );
}