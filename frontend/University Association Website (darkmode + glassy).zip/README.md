
  # University Association Website

  This is a code bundle for University Association Website. The original project is available at https://www.figma.com/design/K32wqmse3QBcyyKwFb4vkD/University-Association-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  