import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Calendar, Clock, Users, BookOpen, ArrowRight, Mail, CheckCircle } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useState } from 'react';
import { toast } from 'sonner@2.0.3';

interface HomePageProps {
  onNavigate: (page: string, id?: string) => void;
}

const recentBlogs = [
  {
    id: '1',
    title: 'The Future of Artificial Intelligence in Computer Engineering',
    excerpt: 'Exploring how AI is revolutionizing the field of computer engineering and its implications for students.',
    author: 'Dr. Ahmad Mohammadi',
    date: '2024-01-15',
    category: 'Technology',
    thumbnail: 'https://images.unsplash.com/photo-1738003667850-a2fb736e31b3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpZmljaWFsJTIwaW50ZWxsaWdlbmNlJTIwcmVzZWFyY2h8ZW58MXx8fHwxNzU3MzQzNjk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '2',
    title: 'Best Practices for Software Development in Academic Projects',
    excerpt: 'A comprehensive guide to implementing industry-standard practices in university software projects.',
    author: 'Prof. Sara Hashemi',
    date: '2024-01-10',
    category: 'Development',
    thumbnail: 'https://images.unsplash.com/photo-1725080503775-a418e90cab6c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2Z0d2FyZSUyMGRldmVsb3BtZW50JTIwY29tcHV0ZXJ8ZW58MXx8fHwxNzU3NDM3MDYyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '3',
    title: 'Career Opportunities in Computer Engineering',
    excerpt: 'Understanding the diverse career paths available for computer engineering graduates.',
    author: 'Dr. Reza Gholami',
    date: '2024-01-08',
    category: 'Career',
    thumbnail: 'https://images.unsplash.com/photo-1752118464988-2914fb27d0f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJlZXIlMjBkZXZlbG9wbWVudCUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NTc0MzcwNjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  }
];

const upcomingEvents = [
  {
    id: '1',
    title: 'Annual Tech Symposium 2024',
    description: 'Join us for presentations on cutting-edge research and industry trends.',
    date: '2024-02-15',
    time: '09:00 AM',
    location: 'Main Auditorium',
    type: 'Symposium',
    thumbnail: 'https://images.unsplash.com/photo-1670382417551-d2f1ee29aea4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNoJTIwY29uZmVyZW5jZSUyMHByZXNlbnRhdGlvbiUyMGF1ZGllbmNlfGVufDF8fHx8MTc1NzQzNzM4Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '2',
    title: 'Workshop: Machine Learning Fundamentals',
    description: 'Hands-on workshop covering the basics of machine learning for beginners.',
    date: '2024-02-10',
    time: '02:00 PM',
    location: 'Computer Lab 1',
    type: 'Workshop',
    thumbnail: 'https://images.unsplash.com/photo-1689236673934-66f8e9d9279b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21wdXRlciUyMGxhYiUyMHdvcmtzaG9wJTIwc3R1ZGVudHN8ZW58MXx8fHwxNzU3NDM3Mzg2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '3',
    title: 'Guest Lecture: Industry Perspectives',
    description: 'Leading industry professionals share insights on current market trends.',
    date: '2024-02-05',
    time: '04:00 PM',
    location: 'Conference Room',
    type: 'Lecture',
    thumbnail: 'https://images.unsplash.com/photo-1646579886135-068c73800308?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwbGVjdHVyZSUyMGhhbGwlMjBwcmVzZW50YXRpb258ZW58MXx8fHwxNzU3NDM3Mzg5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  }
];

export function HomePage({ onNavigate }: HomePageProps) {
  const [email, setEmail] = useState('');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <section className="text-center py-12 bg-gradient-to-r from-primary/5 to-primary/10 rounded-lg mb-12">
        <div className="max-w-4xl mx-auto px-6">
          <h1 className="text-4xl md:text-5xl mb-4 text-foreground">
            Welcome to ACE
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Association of Computer Engineering at Guilan University - Fostering innovation, 
            knowledge sharing, and professional growth in the field of computer engineering.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button onClick={() => onNavigate('blogs')} size="lg" className="px-8">
              <BookOpen className="mr-2 h-5 w-5" />
              Explore Blogs
            </Button>
            <Button onClick={() => onNavigate('events')} variant="outline" size="lg" className="px-8">
              <Calendar className="mr-2 h-5 w-5" />
              View Events
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Members</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">250+</div>
            <p className="text-xs text-muted-foreground">
              Students and faculty members
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Published Articles</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">45</div>
            <p className="text-xs text-muted-foreground">
              Research papers and blog posts
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Events Hosted</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">28</div>
            <p className="text-xs text-muted-foreground">
              Workshops and seminars this year
            </p>
          </CardContent>
        </Card>
      </section>

      {/* Recent Blogs Section */}
      <section className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl text-foreground">Recent Blog Posts</h2>
          <Button variant="outline" onClick={() => onNavigate('blogs')}>
            View All <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recentBlogs.map((blog) => (
            <Card key={blog.id} className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden">
              <div className="h-48 relative">
                <ImageWithFallback
                  src={blog.thumbnail}
                  alt={blog.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="secondary">{blog.category}</Badge>
                  <span className="text-sm text-muted-foreground">{blog.date}</span>
                </div>
                <CardTitle className="line-clamp-2">{blog.title}</CardTitle>
                <CardDescription className="line-clamp-3">{blog.excerpt}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">By {blog.author}</span>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => onNavigate('blog', blog.id)}
                  >
                    Read More
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Upcoming Events Section */}
      <section className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl text-foreground">Upcoming Events</h2>
          <Button variant="outline" onClick={() => onNavigate('events')}>
            View All <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {upcomingEvents.map((event) => (
            <Card key={event.id} className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden">
              <div className="h-48 relative">
                <ImageWithFallback
                  src={event.thumbnail}
                  alt={event.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline">{event.type}</Badge>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Calendar className="mr-1 h-4 w-4" />
                    {event.date}
                  </div>
                </div>
                <CardTitle className="line-clamp-2">{event.title}</CardTitle>
                <CardDescription className="line-clamp-2">{event.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="mr-2 h-4 w-4" />
                    {event.time}
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <span className="mr-2">📍</span>
                    {event.location}
                  </div>
                  <Button 
                    className="w-full mt-4"
                    onClick={() => onNavigate('event', event.id)}
                  >
                    Learn More
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Newsletter Subscription Section */}
      <section className="mb-12">
        <Card className="bg-gradient-to-r from-primary/5 to-primary/10">
          <CardContent className="p-8">
            <div className="text-center max-w-2xl mx-auto">
              <Mail className="w-12 h-12 text-primary mx-auto mb-4" />
              <h2 className="text-3xl text-foreground mb-4">Stay Updated</h2>
              <p className="text-muted-foreground mb-6">
                Subscribe to our newsletter and never miss updates on events, blog posts, 
                research news, and opportunities in computer engineering.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  className="flex-1"
                />
                <Button
                  onClick={() => {
                    if (email && email.includes('@')) {
                      toast.success('Thank you for subscribing to our newsletter!');
                      setEmail('');
                    } else {
                      toast.error('Please enter a valid email address.');
                    }
                  }}
                  className="px-6"
                >
                  <Mail className="mr-2 h-4 w-4" />
                  Subscribe
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-4">
                We respect your privacy. Unsubscribe at any time.
              </p>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}