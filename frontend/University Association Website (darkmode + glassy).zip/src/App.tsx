import { useState } from 'react';
import { AuthProvider } from './components/AuthContext';
import { ThemeProvider } from './components/ThemeContext';
import { Header } from './components/Header';
import { HomePage } from './components/HomePage';
import { BlogsPage } from './components/BlogsPage';
import { EventsPage } from './components/EventsPage';
import { AboutPage } from './components/AboutPage';
import { LoginPage } from './components/LoginPage';
import { RegisterPage } from './components/RegisterPage';
import { ProfilePage } from './components/ProfilePage';
import { UserDashboard } from './components/UserDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedId, setSelectedId] = useState<string | undefined>();

  const handleNavigate = (page: string, id?: string) => {
    setCurrentPage(page);
    setSelectedId(id);
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={handleNavigate} />;
      case 'blogs':
      case 'blog':
        return <BlogsPage onNavigate={handleNavigate} selectedId={selectedId} />;
      case 'events':
      case 'event':
        return <EventsPage onNavigate={handleNavigate} selectedId={selectedId} />;
      case 'about':
        return <AboutPage onNavigate={handleNavigate} />;
      case 'login':
        return <LoginPage onNavigate={handleNavigate} />;
      case 'register':
        return <RegisterPage onNavigate={handleNavigate} />;
      case 'profile':
        return <ProfilePage onNavigate={handleNavigate} />;
      case 'dashboard':
        return <UserDashboard onNavigate={handleNavigate} />;
      case 'admin':
        return <AdminDashboard onNavigate={handleNavigate} />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <AuthProvider>
      <ThemeProvider>
        <div className="min-h-screen bg-background">
          {currentPage !== 'login' && currentPage !== 'register' && (
            <Header currentPage={currentPage} onNavigate={handleNavigate} />
          )}
          <main className={currentPage !== 'login' && currentPage !== 'register' ? "pb-8 pt-24" : ""}>
            {renderCurrentPage()}
          </main>
          <Toaster position="top-right" />
          
          {/* Footer - only show on main pages */}
          {currentPage !== 'login' && currentPage !== 'register' && (
            <footer className="bg-muted py-8 mt-12">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div>
                    <div className="flex items-center space-x-2 mb-4">
                      <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                        <span className="text-primary-foreground font-bold">ACE</span>
                      </div>
                      <div>
                        <h3 className="font-semibold">ACE Guilan</h3>
                        <p className="text-sm text-muted-foreground">Computer Engineering Association</p>
                      </div>
                    </div>
                    <p className="text-muted-foreground text-sm">
                      Fostering innovation and excellence in computer engineering education and research.
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-4">Quick Links</h4>
                    <div className="space-y-2">
                      <button 
                        onClick={() => handleNavigate('home')}
                        className="block text-sm text-muted-foreground hover:text-foreground transition-colors"
                      >
                        Home
                      </button>
                      <button 
                        onClick={() => handleNavigate('blogs')}
                        className="block text-sm text-muted-foreground hover:text-foreground transition-colors"
                      >
                        Blogs
                      </button>
                      <button 
                        onClick={() => handleNavigate('events')}
                        className="block text-sm text-muted-foreground hover:text-foreground transition-colors"
                      >
                        Events
                      </button>
                      <button 
                        onClick={() => handleNavigate('about')}
                        className="block text-sm text-muted-foreground hover:text-foreground transition-colors"
                      >
                        About
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-4">Contact</h4>
                    <div className="space-y-2 text-sm text-muted-foreground">
                      <p>Engineering Faculty</p>
                      <p>Guilan University</p>
                      <p>Rasht, Guilan Province</p>
                      <p>ace@guilan.ac.ir</p>
                    </div>
                  </div>
                </div>
                
                <div className="border-t border-border mt-8 pt-8 text-center">
                  <p className="text-sm text-muted-foreground">
                    © 2024 Association of Computer Engineering, Guilan University. All rights reserved.
                  </p>
                </div>
              </div>
            </footer>
          )}
        </div>
      </ThemeProvider>
    </AuthProvider>
  );
}