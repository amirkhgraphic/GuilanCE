import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Search, Filter, Calendar, Clock, MapPin, Users, ArrowLeft, ExternalLink } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { EventRegistrationForm } from './EventRegistrationForm';
import { CommentSection } from './CommentSection';
import { RatingSection } from './RatingSection';

interface EventsPageProps {
  onNavigate: (page: string, id?: string) => void;
  selectedId?: string;
}

const allEvents = [
  {
    id: '1',
    title: 'Annual Tech Symposium 2024',
    description: 'Join us for presentations on cutting-edge research and industry trends. This symposium brings together students, faculty, and industry professionals.',
    date: '2024-02-15',
    time: '09:00 AM - 05:00 PM',
    location: 'Main Auditorium, Engineering Building',
    type: 'Symposium',
    status: 'upcoming',
    capacity: 200,
    registered: 145,
    organizer: 'ACE Committee',
    tags: ['Research', 'Industry', 'Networking'],
    thumbnail: 'https://images.unsplash.com/photo-1670382417551-d2f1ee29aea4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNoJTIwY29uZmVyZW5jZSUyMHByZXNlbnRhdGlvbiUyMGF1ZGllbmNlfGVufDF8fHx8MTc1NzQzNzM4Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    agenda: [
      '09:00 - Registration & Coffee',
      '10:00 - Keynote: Future of AI',
      '11:30 - Panel: Industry Trends',
      '14:00 - Student Presentations',
      '16:00 - Networking Session'
    ],
    gallery: []
  },
  {
    id: '2',
    title: 'Workshop: Machine Learning Fundamentals',
    description: 'Hands-on workshop covering the basics of machine learning for beginners. Participants will learn practical implementation techniques.',
    date: '2024-02-10',
    time: '02:00 PM - 06:00 PM',
    location: 'Computer Lab 1, Second Floor',
    type: 'Workshop',
    status: 'upcoming',
    capacity: 30,
    registered: 28,
    organizer: 'Dr. Ahmad Mohammadi',
    tags: ['Machine Learning', 'Hands-on', 'Beginner-friendly'],
    thumbnail: 'https://images.unsplash.com/photo-1689236673934-66f8e9d9279b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21wdXRlciUyMGxhYiUyMHdvcmtzaG9wJTIwc3R1ZGVudHN8ZW58MXx8fHwxNzU3NDM3Mzg2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    agenda: [
      '14:00 - Introduction to ML',
      '15:00 - Python for ML',
      '16:00 - First ML Model',
      '17:00 - Model Evaluation',
      '18:00 - Q&A Session'
    ],
    gallery: []
  },
  {
    id: '3',
    title: 'Guest Lecture: Industry Perspectives',
    description: 'Leading industry professionals share insights on current market trends and career opportunities in computer engineering.',
    date: '2024-02-05',
    time: '04:00 PM - 06:00 PM',
    location: 'Conference Room, Third Floor',
    type: 'Lecture',
    status: 'upcoming',
    capacity: 80,
    registered: 65,
    organizer: 'Prof. Sara Hashemi',
    tags: ['Industry', 'Career', 'Professional Development'],
    thumbnail: 'https://images.unsplash.com/photo-1646579886135-068c73800308?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwbGVjdHVyZSUyMGhhbGwlMjBwcmVzZW50YXRpb258ZW58MXx8fHwxNzU3NDM3Mzg5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    agenda: [
      '16:00 - Welcome & Introduction',
      '16:15 - Industry Overview',
      '17:00 - Career Paths',
      '17:30 - Q&A with Professionals',
      '18:00 - Networking'
    ],
    gallery: []
  },
  {
    id: '4',
    title: 'Coding Competition 2024',
    description: 'Annual programming contest for students to showcase their problem-solving skills and compete for prizes.',
    date: '2024-01-28',
    time: '10:00 AM - 04:00 PM',
    location: 'Computer Lab 2 & 3',
    type: 'Competition',
    status: 'past',
    capacity: 50,
    registered: 50,
    organizer: 'Student Programming Club',
    tags: ['Programming', 'Competition', 'Prizes'],
    thumbnail: 'https://images.unsplash.com/photo-1510915228340-29c85a43dcfe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9ncmFtbWluZyUyMGNvbXBldGl0aW9uJTIwaGFja2Vyc3xlbnwxfHx8fDE3NTc0MzczOTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    agenda: [
      '10:00 - Registration & Setup',
      '10:30 - Contest Rules',
      '11:00 - Programming Contest',
      '15:00 - Solution Discussion',
      '16:00 - Award Ceremony'
    ],
    gallery: [
      'https://images.unsplash.com/photo-1709377699246-aa4c66caddfa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50cyUyMGdyb3VwJTIwcGhvdG8lMjBldmVudHxlbnwxfHx8fDE3NTc0Mzc0MjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1726804973612-3e610a28ba3f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9ncmFtbWluZyUyMGF3YXJkJTIwY2VyZW1vbnklMjB3aW5uZXJzfGVufDF8fHx8MTc1NzQzNzQyNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1580894894513-541e068a3e2b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNoJTIwd29ya3Nob3AlMjBoYW5kcyUyMGNvZGluZ3xlbnwxfHx8fDE3NTc0Mzc0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1634836023845-eddbfe9937da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21wdXRlciUyMHNjcmVlbiUyMGNvZGluZyUyMGZvY3VzZWR8ZW58MXx8fHwxNzU3NDM3NDM1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    ]
  },
  {
    id: '5',
    title: 'Cybersecurity Awareness Seminar',
    description: 'Learn about the latest cybersecurity threats and how to protect yourself and your organization.',
    date: '2024-01-20',
    time: '03:00 PM - 05:00 PM',
    location: 'Lecture Hall A',
    type: 'Seminar',
    status: 'past',
    capacity: 100,
    registered: 87,
    organizer: 'Prof. Hassan Karimi',
    tags: ['Cybersecurity', 'Awareness', 'Protection'],
    thumbnail: 'https://images.unsplash.com/photo-1755548413928-4aaeba7c740e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjeWJlcnNlY3VyaXR5JTIwdHJhaW5pbmclMjBzZW1pbmFyfGVufDF8fHx8MTc1NzQzNzM5Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    agenda: [
      '15:00 - Current Threat Landscape',
      '15:45 - Protection Strategies',
      '16:30 - Case Studies',
      '17:00 - Q&A Session'
    ],
    gallery: [
      'https://images.unsplash.com/photo-1754490899591-d386c75e06a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZXR3b3JraW5nJTIwZXZlbnQlMjBwcm9mZXNzaW9uYWxzJTIwdGFsa2luZ3xlbnwxfHx8fDE3NTczODUwNTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1670382417551-d2f1ee29aea4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZWN1cml0eSUyMHByZXNlbnRhdGlvbiUyMGF1ZGllbmNlfGVufDF8fHx8MTc1NzQzNzQzOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    ]
  }
];

export function EventsPage({ onNavigate, selectedId }: EventsPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedEvent, setSelectedEvent] = useState<string | null>(selectedId || null);
  const [isRegistrationOpen, setIsRegistrationOpen] = useState(false);

  const eventTypes = ['all', 'Symposium', 'Workshop', 'Lecture', 'Competition', 'Seminar'];
  const eventStatuses = ['all', 'upcoming', 'past'];

  const filteredEvents = allEvents.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         event.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         event.organizer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || event.type === selectedType;
    const matchesStatus = selectedStatus === 'all' || event.status === selectedStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  const currentEvent = selectedEvent ? allEvents.find(event => event.id === selectedEvent) : null;

  if (currentEvent) {
    return (
      <>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Button 
            variant="ghost" 
            onClick={() => setSelectedEvent(null)}
            className="mb-6"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Events
          </Button>
          
          <div className="space-y-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <Badge className="mb-4" variant={currentEvent.status === 'upcoming' ? 'default' : 'secondary'}>
                  {currentEvent.type} • {currentEvent.status}
                </Badge>
                <h1 className="text-4xl mb-4">{currentEvent.title}</h1>
                <div className="w-full h-64 md:h-80 mb-6 rounded-lg overflow-hidden">
                  <ImageWithFallback
                    src={currentEvent.thumbnail}
                    alt={currentEvent.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <p className="text-xl text-muted-foreground mb-6">
                  {currentEvent.description}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Event Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center">
                    <Calendar className="mr-3 h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{currentEvent.date}</p>
                      <p className="text-sm text-muted-foreground">{currentEvent.time}</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <MapPin className="mr-3 h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{currentEvent.location}</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Users className="mr-3 h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">
                        {currentEvent.registered} / {currentEvent.capacity} registered
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Organized by {currentEvent.organizer}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Registration</CardTitle>
                </CardHeader>
                <CardContent>
                  {currentEvent.status === 'upcoming' ? (
                    <div className="space-y-4">
                      <div className="p-4 bg-muted rounded-lg">
                        <p className="text-sm text-muted-foreground mb-2">Available Spots</p>
                        <p className="text-2xl font-bold">
                          {currentEvent.capacity - currentEvent.registered}
                        </p>
                      </div>
                      <Button 
                        className="w-full" 
                        size="lg"
                        onClick={() => setIsRegistrationOpen(true)}
                      >
                        Register Now
                      </Button>
                      <p className="text-xs text-muted-foreground text-center">
                        Registration is free for all students and faculty
                      </p>
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-muted-foreground mb-4">This event has ended</p>
                      <Button variant="outline" disabled>
                        Registration Closed
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Agenda</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {currentEvent.agenda.map((item, index) => (
                    <div key={index} className="flex items-center py-2 border-b border-border last:border-b-0">
                      <Clock className="mr-3 h-4 w-4 text-muted-foreground" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tags</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {currentEvent.tags.map((tag) => (
                    <Badge key={tag} variant="outline">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Event Gallery - only show for past events with photos */}
            {currentEvent.status === 'past' && currentEvent.gallery && currentEvent.gallery.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Event Gallery</CardTitle>
                  <CardDescription>
                    Photos from the event
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {currentEvent.gallery.map((photo, index) => (
                      <div key={index} className="aspect-video rounded-lg overflow-hidden">
                        <ImageWithFallback
                          src={photo}
                          alt={`${currentEvent.title} - Photo ${index + 1}`}
                          className="w-full h-full object-cover hover:scale-105 transition-transform duration-200 cursor-pointer"
                        />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Comments Section */}
            <CommentSection postId={currentEvent.id} postType="event" />

            {/* Rating Section - only show for past events */}
            {currentEvent.status === 'past' && (
              <RatingSection eventId={currentEvent.id} canRate={true} />
            )}
          </div>
        </div>

        {/* Registration Form Modal */}
        <EventRegistrationForm
          isOpen={isRegistrationOpen}
          onClose={() => setIsRegistrationOpen(false)}
          eventTitle={currentEvent.title}
          eventId={currentEvent.id}
        />
      </>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-4xl mb-4">Events</h1>
        <p className="text-xl text-muted-foreground">
          Workshops, seminars, and networking opportunities for our community
        </p>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search events..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={selectedType} onValueChange={setSelectedType}>
          <SelectTrigger className="w-full sm:w-48">
            <Filter className="mr-2 h-4 w-4" />
            <SelectValue placeholder="Event Type" />
          </SelectTrigger>
          <SelectContent>
            {eventTypes.map((type) => (
              <SelectItem key={type} value={type}>
                {type === 'all' ? 'All Types' : type}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={selectedStatus} onValueChange={setSelectedStatus}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            {eventStatuses.map((status) => (
              <SelectItem key={status} value={status}>
                {status === 'all' ? 'All Events' : status === 'upcoming' ? 'Upcoming' : 'Past Events'}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Events Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredEvents.map((event) => (
          <Card key={event.id} className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden">
            <div className="h-48 relative">
              <ImageWithFallback
                src={event.thumbnail}
                alt={event.title}
                className="w-full h-full object-cover"
              />
            </div>
            <CardHeader>
              <div className="flex items-center justify-between mb-2">
                <Badge variant={event.status === 'upcoming' ? 'default' : 'secondary'}>
                  {event.type}
                </Badge>
                <Badge variant={event.status === 'upcoming' ? 'default' : 'outline'}>
                  {event.status}
                </Badge>
              </div>
              <CardTitle className="line-clamp-2">{event.title}</CardTitle>
              <CardDescription className="line-clamp-3">{event.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center text-sm text-muted-foreground">
                  <Calendar className="mr-2 h-4 w-4" />
                  {event.date}
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Clock className="mr-2 h-4 w-4" />
                  {event.time}
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <MapPin className="mr-2 h-4 w-4" />
                  {event.location}
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Users className="mr-2 h-4 w-4" />
                  {event.registered}/{event.capacity} registered
                </div>
                <div className="flex flex-wrap gap-1 mb-3">
                  {event.tags.slice(0, 2).map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {event.tags.length > 2 && (
                    <Badge variant="outline" className="text-xs">
                      +{event.tags.length - 2}
                    </Badge>
                  )}
                </div>
                <Button 
                  className="w-full"
                  onClick={() => setSelectedEvent(event.id)}
                >
                  View Details
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredEvents.length === 0 && (
        <div className="text-center py-12">
          <p className="text-xl text-muted-foreground">
            No events found matching your search criteria.
          </p>
        </div>
      )}
    </div>
  );
}